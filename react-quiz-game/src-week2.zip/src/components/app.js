import React from "react";
import WelcomeMessage from "./welcome-message";

function App() {
  return (
    <main>
      <h1>My first react app!</h1>

      <WelcomeMessage greeting="Howdy" name="Sarah"></WelcomeMessage>
      <WelcomeMessage greeting="Good Morning" name="Class"></WelcomeMessage>
    </main>
  );
}

export default App;
