import ReactDOM from "react-dom";
import React from "react";
import App from "./components/app";
import "./main.css";

const root = document.querySelector("#root");

ReactDOM.render(<App />, root);
