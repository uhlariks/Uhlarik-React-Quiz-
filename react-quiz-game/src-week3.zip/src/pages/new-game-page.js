import React from "react";
import NewGameForm from "../components/new-game-form";

function NewGamePage() {
  return <NewGameForm></NewGameForm>;
}

export default NewGamePage;
