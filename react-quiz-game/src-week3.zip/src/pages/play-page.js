import React from "react";

function PlayPage() {
  return <div>Play Page</div>;
}

export default PlayPage;
